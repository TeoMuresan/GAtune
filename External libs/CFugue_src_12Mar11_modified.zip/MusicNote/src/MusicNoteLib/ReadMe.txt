MusicNote Library
