
This is part of CFugue Test suit.

This demonstrates the usage of MusicNoteDll, which can be built only on Windows platforms since it is a COM DLL.

For other platforms, use the Static library.